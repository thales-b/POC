javac SeptNains.java
java SeptNains
